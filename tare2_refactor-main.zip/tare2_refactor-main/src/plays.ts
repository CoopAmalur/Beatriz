const plays = '{"hamlet": {"name": "Hamlet", "type": "tragedy"}, "as-like":{"name": "As You Like It", "type": "comedy"},"othello": {"name": "Othello", "type": "tragedy"}}';

export {plays};