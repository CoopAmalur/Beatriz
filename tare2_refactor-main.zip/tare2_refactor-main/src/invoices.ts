const invoices = '[{"customer": "BigCo", "performances": [ {"playID": "hamlet","audience": 55}, { "playID": "as-like", "audience": 35},{"playID": "othello","audience": 40}]}]';

export {invoices};