export const MAX_WORD_SIZE:number = 5;
export const MAX_ATTEMPTS:number = 6;