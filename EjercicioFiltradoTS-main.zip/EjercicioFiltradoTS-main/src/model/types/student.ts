export interface Student {
    id: number,
    name: number,
    firstSurname: string,
    secondSurname: string,
    personalEmailAddress: string,
    activaEmailAddress: string,
    phoneNumber: string,
    zipCode: string
}